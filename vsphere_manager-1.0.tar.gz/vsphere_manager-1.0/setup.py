# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['operations', 'operations.tools', 'vsphere_manager']

package_data = \
{'': ['*']}

install_requires = \
['click==8.0.1',
 'pyvim==3.0.2',
 'pyvmomi==7.0.2',
 'requests==2.25.1',
 'tools==0.1.9']

entry_points = \
{'console_scripts': ['vsphere_clone_vm = vsphere_manager:clone_vms',
                     'vsphere_connect = vsphere_manager:connect_vsphere',
                     'vsphere_list_vms = vsphere_manager:list_vms',
                     'vsphere_poweroff_vm = vsphere_manager:power_off_vms',
                     'vsphere_poweron_vm = vsphere_manager:power_on_vms',
                     'vsphere_remove_vm = vsphere_manager:remove_vms']}

setup_kwargs = {
    'name': 'vsphere-manager',
    'version': '1.0',
    'description': 'vSphere manager',
    'long_description': None,
    'author': 'BAE-LSV-Ericsson',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
