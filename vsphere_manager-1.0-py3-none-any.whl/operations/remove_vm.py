#!/usr/bin/env python

"""
Delete a VM from host
"""

from pyVmomi import vim

from .tools import cli, service_instance, tasks, pchelper


def main():
    parser = cli.Parser()
    parser.add_optional_arguments(cli.Argument.VM_NAME)
    args = parser.get_args()
    si = service_instance.connect(args)

    virtualmachine = None
    if args.vm_name:
        try:
            virtualmachine = pchelper.get_obj(si.content, [vim.VirtualMachine], args.vm_name)
        except RuntimeError:
            print("Unable to locate VirtualMachine: {0}".format(args.vm_name))
            return exit(100)

    if virtualmachine is None:
        print("Unable to locate VirtualMachine: {0}".format(args.vm_name))
        return exit(100)

    print("Found: {0}".format(virtualmachine.name))
    print("The current powerState is: {0}".format(virtualmachine.runtime.powerState))
    if format(virtualmachine.runtime.powerState) == "poweredOn":
        print("Attempting to power off {0}".format(virtualmachine.name))
        TASK = virtualmachine.PowerOffVM_Task()
        tasks.wait_for_tasks(si, [TASK])
        print("{0}".format(TASK.info.state))

    print("Destroying VM from vSphere.")
    TASK = virtualmachine.Destroy_Task()
    tasks.wait_for_tasks(si, [TASK])
    print("Done.")


# Start program
if __name__ == "__main__":
    main()
