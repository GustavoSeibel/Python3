from operations import remove_vm as remove, connect, multi_clone as clone, list_vm, power_on_vm, power_off_vm


def remove_vms():
    remove.main()


def list_vms():
    list_vm.main()


def clone_vms():
    clone.main()


def connect_vsphere():
    connect.main()


def power_on_vms():
    power_on_vm.main()


def power_off_vms():
    power_off_vm.main()
